# Inplace regression suite

## Live overlay regression, 1.3.9

The final test results and retained evidence are in
[`tests/overlay/README.md`](../overlay/README.md).
New sources use the existing `tests/inplace/` convention; intermediate outputs
are isolated under `tmp/overlay-bugfix/`.

`qml/tst_overlaylifecycle.qml` verifies that settings echoes, translation updates
and switching the persistent window surfaces preserve a native resize. It also
checks the remembered-size setting and explicit size edits.

The following opt-in tests require the actual user's KWin session and PySide6:

```sh
cargo build --offline -p lipa --bin lipax --features lifecycle-test
python tests/inplace/python/kwin_geometry_probe.py
QT_QPA_PLATFORM=wayland python tests/inplace/python/live_overlay_pipeline.py
QT_QPA_PLATFORM=xcb python tests/inplace/python/live_overlay_pipeline.py
python tests/inplace/python/live_floating_window.py
```

The live pipeline requires Tesseract English, network access to Google Translate,
Spectacle and the application's normal ScreenShot2 desktop-entry authorization.
For a local binary, use the documented `packaging/run-local.sh` registration.
Only generated test-owned source windows are captured or moved. Translation
data is produced by the real pipeline, not injected. Real QQuickWindow buffers
are checked for glyphs; on one physical output, a compositor screenshot verifies
that both independent field buffers appear at their reported coordinates.
Movement must redraw fields without another translation request. A changed
phrase must produce a new translation. Shutdown must exit normally.

The floating probe uses XTest on the application's XCB top-level. Exit code 77
means KWin did not accept the synthetic pointer motion; this leaves dragging
unverified. A physical pointer is required for native Wayland movement and
resizing validation. `QT_SCALE_FACTOR` exercises Qt coordinate arithmetic only;
it does not validate compositor fractional scaling or multiple physical outputs.

## Existing offline suite

All new task-specific tests live here. Existing application and Kizurium tests
remain in their original directories. Cargo registers `rust/regression.rs` and
`rust/bench.rs` explicitly in `crates/core/Cargo.toml`.

Run `bash tests/inplace/run.sh` from the repository. It writes all builds,
bytecode, caches, logs, images and measurements under `tmp/`. Dependencies:
Rust dependencies already cached for `--offline`, Qt 6 development tools,
C++ compiler, Pillow, pytest, PySide6, ONNX Runtime and cached RapidOCR models.
Use `LIPAX_RAPID_TEST_MODELS` and `LIPAX_RAPID_TEST_ORT` to select existing
models/runtime; models are not downloaded by this suite. CPU, two threads, no GPU.
Existing HTTP mock tests need permission to bind loopback sockets.

- `rust/`: coordinate, appearance hysteresis, confidence, empty-input/OCR-line
  normalization, connectivity and slant regressions; diagnostic screenshot executable.
- `qml/`: QML lifecycle/geometry and the production JavaScript coordinate helper.
- `qt/`: production QTextLayout helper tests, measurement timings and a test-only
  JSON-lines server for Rust fitting with the shared production Qt helper.
- `python/`: 16 real screenshot pipeline cases, bundled multilingual glyph coverage, and a negative visual comparator
  test. The initially extensionless `dialogue-en-12` JPEG was renamed to `.jpg`
  during the task; both names are supported. `dialogue-en-13.png` is 1821×1032, `-14` is 1867×1063, and `-15` is
  1732×996. Translucent PNG borders are composited onto black explicitly to
  provide an opaque capture-frame input.

The runner builds the Qt measurement server and sets `LIPAX_QT_MEASURE_SERVER`.
Rust screenshot placement then uses the same font constructor and QTextLayout
helper as the application, via test-only IPC. QML renders the resulting entries;
tests inspect actual line counts, content sizes and truncation as well as pixels.
This exercises Rust fitting and the production C++ helper together, but does not
execute the application's in-process CXX-Qt transport or a live compositor.
Without that environment variable, the executable uses `ApproxMeasure` for
CPU diagnostics; its metadata states which measurer was used. IPC timings must
not be reported as application layout latency. Translations are predefined, never sent to a service. OCR can run
independently with `LIPAX_TEST_OCR=1`; output is from LipaX's native RapidOCR
backend, not fixture coordinates. No silent fallback to another OCR backend is allowed. There are no OCR ground-truth annotations
in this dataset, so these tests make no claim about recognition accuracy.

Four additional Qt cases cover long dialogue, long words, hard breaks and mixed
shaping. A fifth case uses `--ocr-blocks`: actual cropped OCR jobs pass through
the application's RapidOCR backend, confidence/meaningfulness gates and
OCR-line refinement before receiving predefined translations. This verifies
transport and rejection gates, not correct transcription. RapidOCR reads the
outlined `dialogue-en-13` dialogue with 99.1% confidence in the observed run;
confidence alone is not proof of transcription or overlay correctness. The default screenshot cases deliberately translate
every detection candidate (including scenery) to stress fitting and clipping.

Artifacts: original image, detected candidates, typography metadata, actual
QML-rendered image, actual layout/overflow diagnostics, outside-boundary difference,
OCR lines and timings.
`render_ms` includes an intentional settling wait; `update_ms` is a synchronous
offscreen update/paint sample, not compositor latency or a delegate-lifecycle
benchmark. Detection candidates can include non-text scenery.

For an independently reviewed reference set, set `LIPAX_VISUAL_REFERENCES` to a
directory containing `<screenshot-stem>.png`. The suite saves differences and
requires channel changes above 8 on no more than 0.1% of pixels. Pin Qt, fonts,
DPI, and render backend when approving references. References are never created
or approved automatically. Without references, only structural and outside-field
pixel invariants are checked; approved-image regression is NOT RUN.

For a paired CPU comparison, save the release `inplace_bench` executable before
editing sources, rebuild it afterwards, and run (with the same cache environment):

```sh
python tests/inplace/python/benchmark.py tmp/phase23/baseline/inplace_bench tmp/cargo-target/release/examples/inplace_bench
```

This alternates baseline/candidate order over three rounds on all screenshots,
checks exact metadata/placement equality, and writes raw samples and summary into
`tmp/phase23/paired-benchmark/`. Both binaries use ApproxMeasure for equivalent
placement conditions. Image candidate correctness still needs labeled data.


Authorized live captures of `engine.exe` and `CrossxMars.exe` can be collected
with `python tests/inplace/python/live_capture.py --capture`. This requires the
host session DBus/KWin connection. Its temporary KWin script is unloaded and
initial minimized/focus state restored. Capture uses Spectacle's registered
KWin backend, not the application's own capture transport. Set
`LIPAX_LIVE_CAPTURE_MANIFEST=tmp/rapid-live/capture/windows.json` to include the
two optional live-frame cases. The current fixture explicitly checks a 1:1
capture/logical scale; other DPRs need a corresponding rendering fixture.

`overlay_quality` records accepted OCR that was not rendered and fallback modes.
These diagnostics expose missing translations even when clipping tests pass.
They do not constitute an annotated OCR/placement accuracy score. Inspect the
rendered image and the missing-block list together.

Set `LIPAX_SAVE_TRANSLATIONS=1` to save user-requested permanent rendered PNGs,
UTF-8 translated text and JSON diagnostics in
`docs/screenshots/test-game/translations/`. These are deterministic test
translations, not translation-service results or approved visual references.
All intermediate artifacts still stay in `tmp/`. Dataset discovery excludes
this output subdirectory.


The recorded engine.exe case also requires both observed dialogue readings to
be rendered over at least 90% of their OCR boxes, without beside-original labels.
New Rust cases cover word-fragment reconstruction, prevention of neighbouring
OCR-padding overlap and exact cached geometry across an identical next frame.
The recorded CrossxMars.exe regression was rerun on the current source on
2026-10-12: the actual RapidOCR → Rust layout → shared Qt measurement → QML
render test passed. Name, complete dialogue and HUD replacements met the
existing source-coverage checks; `uncovered_text_blocks` was empty and
`repeat_ocr_jobs` was zero. This closes the previously reported recorded-frame
diagnostic failure within this fixture's coverage. It is an offscreen test
with predefined translations, not a live-game compositor test. Evidence is in
`tests/overlay/evidence/crossxmars/`.

New files added in the 2026-10-11 session (Stage 3–5):

- `rust/detection.rs` (`inplace_detection`): block detector tests, `DetectionReport`
  with listed dropped blocks, the local contrast pass and the noise filters.
- `rust/typography.rs` (`inplace_typography`): typography measurement against ab_glyph
  outlines, `category_confidence` calibration over the fixtures and sequence tests
  (weight change, style change, block return).
- `rust/stress.rs` (`inplace_stress`): 200 frames × 12 blocks; checks tracked ≤ 12 and
  that RSS does not grow. Debug timings are not a benchmark.
- `rust/detect_dump.rs` (example `inplace_detect_dump`): diagnostic printer of the
  detector's blocks and report for a PNG/JPEG. It runs no OCR and makes no accuracy claim.
- `qt/typography_probe.cpp`: Qt probe used by the typography test; it runs in an
  environment without system fonts, so only the bundled fonts are available.
- `python/test_typography_qt.py`: 11 Qt tests. Without system fonts, Latin, Cyrillic, Greek
  and CJK come only from the bundled set and Thai gives `.notdef`. With system fonts, Thai
  and Arabic come from the OS.
